When the project is updated

- Check if README.md needs updating to reflect new features or changes
- Update the Pages section if new pages are added
- Update the Design Features section if new design elements are introduced
- Update the Customization section if new customization options are available