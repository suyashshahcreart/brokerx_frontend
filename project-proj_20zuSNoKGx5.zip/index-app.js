const featuredProperties = [
    {
        id: 1,
        image: 'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=800',
        title: 'Luxury Penthouse',
        location: 'Downtown District',
        price: '$2,500,000',
        beds: 4,
        baths: 3,
        area: '3500 sq ft'
    },
    {
        id: 2,
        image: 'https://images.unsplash.com/photo-1600566753086-00f18fb6b3ea?w=800',
        title: 'Modern Villa',
        location: 'Riverside Estate',
        price: '$3,200,000',
        beds: 5,
        baths: 4,
        area: '4500 sq ft'
    },
    {
        id: 3,
        image: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=800',
        title: 'Contemporary Apartment',
        location: 'City Center',
        price: '$1,800,000',
        beds: 3,
        baths: 2,
        area: '2500 sq ft'
    }
];

function renderFeaturedProperties() {
    const container = document.getElementById('featuredProperties');
    featuredProperties.forEach(property => {
        const card = `
            <div class="col-md-4">
                <div class="property-card">
                    <img src="${property.image}" alt="${property.title}" class="property-image" loading="lazy">
                    <div class="property-body">
                        <h5 class="mb-2">${property.title}</h5>
                        <p class="text-muted mb-3"><i class="icon-map-pin"></i> ${property.location}</p>
                        <div class="property-price mb-3">${property.price}</div>
                        <div class="d-flex justify-content-between text-muted">
                            <span><i class="icon-bed"></i> ${property.beds} Beds</span>
                            <span><i class="icon-bath"></i> ${property.baths} Baths</span>
                            <span><i class="icon-maximize"></i> ${property.area}</span>
                        </div>
                    </div>
                </div>
            </div>
        `;
        container.innerHTML += card;
    });
}

document.addEventListener('DOMContentLoaded', renderFeaturedProperties);